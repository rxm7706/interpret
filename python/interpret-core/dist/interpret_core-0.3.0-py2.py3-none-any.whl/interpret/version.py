# Copyright (c) 2019 Microsoft Corporation
# Distributed under the MIT software license

# NOTE: Version is replaced by a regex script.
__version__ = "0.3.0"
